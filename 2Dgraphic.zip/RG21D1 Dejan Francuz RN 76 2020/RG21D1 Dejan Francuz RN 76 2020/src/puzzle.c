#include <main_state.h>
#include <glad/glad.h>
#include <math.h>

#include <rafgl.h>

#include <main_state.h>

/** 75 vertikalnih piksela po puzli, po ivici
    na 37 je sredina
    if y == 29 , crtamo polukrug sa centrom u y=29+9 i x = x+3(ako polukrug ide u desno), odnosno x = x-3 (ako polukrug ide u levo), crtamo dve vertikalne linije od 3 piksela, radi estetike
    za y < 29 || y > 47 crtamo prave linija, odnosno obicne piksele u 'colour' boji



    86 horizontalnih piksela po ivici puzle
    na 43 je sredina
    if x == 34, crtamo polukrug sa centrom x = x+9 i y = y+3(ako polukrug ide na gore), odnosno y = y-3(ako polukrug ide na dole), crtamo dve horizontalne linije od 3 piksela
    za x < 34 || x > 52 crtamo prave linije, odnosno obicne piksele u 'colour' boji


**/

static int flag = 0; /** da ne bi za svaku krivulju svaki put randomovali na koju stranu ce da ide, to radimo samo kada puzlu crtamo prvi put,
                svaki sledeci put proveravamo strukturu puzzle i gledamo koju krivulju treba da nacrtamo
                    ako je flag == 0, crtamo puzlu prvi put, ako je flag == 1, crtamo puzlu kakvu vec imamo
                    ovo radimo da se puzla ne bi iscrtavalo samo jedanput, nego u svakom frejmu**/

typedef struct puzzle{
    int x,y; /** x - redni broj puzle u redu, y - redni broj puzle u koloni **/
    int curlies[4];

}puzzle;

puzzle puzzles[12*9];

static int replaced = 0; /** da se dve puzle ne bi neprestano zamenjivale, to cemo uraditi samo jednom, kada je replaced = 0, posle toga replaced stavljamo na 1 **/

static puzzle puzzle1,puzzle2;

static uint32_t colour = rafgl_RGB(255,255,0);

static int raster_width, raster_height;

void draw_puzzle(rafgl_raster_t raster){
    raster_width = raster.width, raster_height = raster.height;
    int numx = raster_width/12;
    int num=numx;
    int helpy = raster_height/9;
    int numy = helpy;
    if(!flag){
    for(num; num < raster_width ;){
        for(int y=0; y<raster_height; y++){
                if(y%75 == 29)draw_vertical(raster, num, y);
                else if(y%75 < 29 || y%75 > 47)pixel_at_m(raster, num, y).rgba = colour;
        }
        num+=numx;
    }
    for(numy; numy < raster_height ;){
        for(int x=0; x < raster_width; x++){
                if(x%86 == 34)draw_horizontal(raster, x, numy);
                else if(x%86 < 34 || x%86 > 52) pixel_at_m(raster, x, numy).rgba = colour;
        }
        numy+=helpy;
    }
    flag = 1;
    }else{
    for(num-1; num < raster_width ;){
        for(int y=0; y<raster_height; y++){
                if(y%75 == 29)again_draw_vertical(raster, num, y);
                else if(y%75 < 29 || y%75 > 47)pixel_at_m(raster, num, y).rgba = colour;
        }
        num+=numx;
    }
    for(numy; numy < raster_height ;){
        for(int x=0; x < raster_width; x++){
                if(x%86 == 34)again_draw_horizontal(raster, x, numy);
                else if(x%86 < 34 || x%86 > 52) pixel_at_m(raster, x, numy).rgba = colour;
        }
        numy+=helpy;
    }
    }
}

void draw_vertical(rafgl_raster_t raster, int x, int y){
    const int rnd = rand()%2;
    int dx,dy;
    if(rnd){
            make_puzzle(x-10, y, 0, -1);
            make_puzzle(x, y, 2, 1);
            rafgl_raster_draw_line(&raster, x, y, x-3, y, colour);
            rafgl_raster_draw_line(&raster, x, y+18, x-3, y+18, colour);
            draw_halfcircle_left(&raster, x-3, y+9, 9, colour);

    }
    else {
            make_puzzle(x-10, y, 0, 1);
            make_puzzle(x, y, 2, -1);
            rafgl_raster_draw_line(&raster, x, y, x+3, y, colour);
            rafgl_raster_draw_line(&raster, x, y+18, x+3, y+18, colour);
            draw_halfcircle_right(&raster, x+3, y+9, 9, colour);

    }

}

void draw_horizontal(rafgl_raster_t raster, int x, int y){
    const int rnd = rand()%2;
        if(rnd){
            make_puzzle(x, y-10, 1, 1);
            make_puzzle(x, y, 3, -1);
            rafgl_raster_draw_line(&raster, x, y, x, y+3, colour);
            rafgl_raster_draw_line(&raster, x+18, y, x+18, y+3, colour);
            draw_halfcircle_up(&raster, x+9, y+3, 9, colour);

    }
    else{
            make_puzzle(x, y-10, 1, -1);
            make_puzzle(x, y, 3, 1);
            rafgl_raster_draw_line(&raster, x, y, x, y-3, colour);
            rafgl_raster_draw_line(&raster, x+18, y, x+18, y-3, colour);
            draw_halfcircle_down(&raster, x+9, y-3, 9, colour);

    }

}
void again_draw_vertical(rafgl_raster_t raster, int x, int y){
        int rnd = puzzles[(x+10)/86 + 12*(y/75)].curlies[2];
        if(rnd>0){
            rafgl_raster_draw_line(&raster, x, y, x-3, y, colour);
            rafgl_raster_draw_line(&raster, x, y+18, x-3, y+18, colour);
            draw_halfcircle_left(&raster, x-3, y+9, 9, colour);

    }
    else if (rnd<0){
            rafgl_raster_draw_line(&raster, x, y, x+3, y, colour);
            rafgl_raster_draw_line(&raster, x, y+18, x+3, y+18, colour);
            draw_halfcircle_right(&raster, x+3, y+9, 9, colour);
    }
}
void again_draw_horizontal(rafgl_raster_t raster, int x, int y){
    int rnd = puzzles[x/86 + 12*((y+10)/75)].curlies[3];
        if(rnd<0){
            rafgl_raster_draw_line(&raster, x, y, x, y+3, colour);
            rafgl_raster_draw_line(&raster, x+18, y, x+18, y+3, colour);
            draw_halfcircle_up(&raster, x+9, y+3, 9, colour);

    }
    else if (rnd>0){
            rafgl_raster_draw_line(&raster, x, y, x, y-3, colour);
            rafgl_raster_draw_line(&raster, x+18, y, x+18, y-3, colour);
            draw_halfcircle_down(&raster, x+9, y-3, 9, colour);
    }

}

void draw_halfcircle_right(rafgl_raster_t *raster, int cx, int cy, int r, uint32_t colour)
{
    int x = -r, y = 0, err = 2-2*r; /* II. Quadrant */
    do {
        pixel_at_pm(raster, cx-x, cy+y).rgba = colour; /*   I. Quadrant */
        pixel_at_pm(raster, cx+y, cy+x).rgba = colour; /*  IV. Quadrant */
        r = err;
        if (r <= y) err += ++y*2+1;           /* e_xy+e_y < 0 */
        if (r > x || err > y) err += ++x*2+1; /* e_xy+e_x > 0 or no 2nd y-step */
    } while (x < 0);
}

void draw_halfcircle_left(rafgl_raster_t *raster, int cx, int cy, int r, uint32_t colour)
{
    int x = -r, y = 0, err = 2-2*r; /* II. Quadrant */
    do {
        pixel_at_pm(raster, cx-y, cy-x).rgba = colour; /*  II. Quadrant */
        pixel_at_pm(raster, cx+x, cy-y).rgba = colour; /* III. Quadrant */
        r = err;
        if (r <= y) err += ++y*2+1;           /* e_xy+e_y < 0 */
        if (r > x || err > y) err += ++x*2+1; /* e_xy+e_x > 0 or no 2nd y-step */
    } while (x < 0);
}

void draw_halfcircle_up(rafgl_raster_t *raster, int cx, int cy, int r, uint32_t colour)
{
    int x = -r, y = 0, err = 2-2*r; /* II. Quadrant */
    do {
        pixel_at_pm(raster, cx-x, cy+y).rgba = colour; /*   I. Quadrant */
        pixel_at_pm(raster, cx-y, cy-x).rgba = colour; /*  II. Quadrant */
        r = err;
        if (r <= y) err += ++y*2+1;           /* e_xy+e_y < 0 */
        if (r > x || err > y) err += ++x*2+1; /* e_xy+e_x > 0 or no 2nd y-step */
    } while (x < 0);
}

void draw_halfcircle_down(rafgl_raster_t *raster, int cx, int cy, int r, uint32_t colour)
{
    int x = -r, y = 0, err = 2-2*r; /* II. Quadrant */
    do {
        pixel_at_pm(raster, cx+x, cy-y).rgba = colour; /* III. Quadrant */
        pixel_at_pm(raster, cx+y, cy+x).rgba = colour; /*  IV. Quadrant */
        r = err;
        if (r <= y) err += ++y*2+1;           /* e_xy+e_y < 0 */
        if (r > x || err > y) err += ++x*2+1; /* e_xy+e_x > 0 or no 2nd y-step */
    } while (x < 0);
}

void make_puzzle(int x, int y, int curl, int value){
            int dx,dy;
            dx = x/86;
            dy = y/75;
            puzzle p = puzzles[dx + dy*12];
            if(!p.curlies[curl])p.curlies[curl] = value;
            p.x = dx;
            p.y = dy;
            puzzles[dx + dy*12] = p;
}

void replace_first_part(rafgl_raster_t raster){

    int i1,j1,i2,j2,i,j;
    i1 = puzzle1.x*86+1;
    i2 = puzzle2.x*86+1;
    j1 = puzzle1.y*75+1;
    j2 = puzzle2.y*75+1;
    if(i1 == 1){
        i1--;
        i2--;
    }
    for(j = j1+12; j < j1+28; j++){
        for(i = i1 ; i < i1+85; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }
        }
    }

}

void replace_second_part(rafgl_raster_t raster){

    int i1,j1,i2,j2,i,j;
    i1 = puzzle1.x*86+1;
    i2 = puzzle2.x*86+1;
    j1 = puzzle1.y*75+1;
    j2 = puzzle2.y*75+1;
    if(i1 == 1){
        i1--;
        i2--;
    }
    for(j = j1+46; j < j1+63; j++){
        for(i = i1 ; i < i1+85; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }
        }
    }
}


/** ako je c == 1, znaci da je ispupcenje na kraju puzle, ako je c == -1, znaci da je udubljenje na vrhu puzle, ako je c == 0, nema udubljenja  **/
void north(rafgl_raster_t raster, int c){
    int i1,j1,i2,j2,i,j;
    i1 = puzzle1.x*86+1;
    i2 = puzzle2.x*86+1;
    j1 = puzzle1.y*75;
    j2 = puzzle2.y*75;
    if(i1 == 1){
        i1--;
        i2--;
    }

    switch(c){

case 1:
    for(i = i1+30; i < i1+51; i++){
        for(j = j1 ; j > j1-12; j--){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2-(j1-j));
                    pixel_at_m(raster, i2+(i-i1),j2-(j1-j)) = temp;
        }else break;
        }
    }
    for(j = j1; j < j1+13; j++){
        for(i = i1 ; i < i1+85; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }

    break;
case -1:
    for(j = j1; j < j1+13; j++){
        for(i = i1 ; i < i1+40; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }
    for(j = j1; j < j1+13; j++){
        for(i = i1+84 ; i > i1+42; i--){ /** oo **/
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }

    break;
case 0:
    for(j = j1; j < j1+13; j++){
        for(i = i1 ; i < i1+85; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }

    break;


    }
}

void south(rafgl_raster_t raster, int c){
    int i1,j1,i2,j2,i,j;
    i1 = puzzle1.x*86+1;
    i2 = puzzle2.x*86+1;
    j1 = puzzle1.y*75+1;
    j2 = puzzle2.y*75+1;
    if(i1 == 1){
        i1--;
        i2--;
    }

    switch(c){

case 1:
    for(i = i1+30; i < i1+51; i++){
        for(j = j1+74 ; j < j1+88; j++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2-(j1-j));
                    pixel_at_m(raster, i2+(i-i1),j2-(j1-j)) = temp;
        }else break;
        }
    }
    for(j = j1+63; j < j1+74; j++){
        for(i = i1 ; i < i1+85; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }

    break;
case -1:
    for(j = j1+63; j < j1+74; j++){
        for(i = i1 ; i < i1+42; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }
    for(j = j1+63; j < j1+74; j++){
        for(i = i1+84 ; i > i1+41; i--){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }

    break;
case 0:
    for(j = j1+63; j < j1+74; j++){
        for(i = i1 ; i < i1+84; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }

    break;


    }

}

void mid(rafgl_raster_t raster, int c){
    int i1,j1,i2,j2,i,j;
    i1 = puzzle1.x*86+1;
    i2 = puzzle2.x*86+1;
    j1 = puzzle1.y*75+1;
    j2 = puzzle2.y*75+1;


    for(j = j1+28; j < j1+46; j++){
        for(i = i1+45 ; i > i1-13 && i >= 0; i--){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }
    for(j = j1+28; j < j1+46; j++){
        for(i = i1+46 ; i < i1+100 && i < raster_width; i++){
                if(pixel_at_m(raster,i,j).rgba != colour){
                    rafgl_pixel_rgb_t temp = pixel_at_m(raster, i,j);
                    pixel_at_m(raster, i,j) = pixel_at_m(raster, i2+(i-i1),j2+(j-j1));
                    pixel_at_m(raster, i2+(i-i1),j2+(j-j1)) = temp;
        }else break;
        }
    }
}

void replace_puzzles(rafgl_raster_t raster){
    int flagator = 1;
    for(int i=0;i<4;i++){
    if(puzzle1.curlies[i]!=puzzle2.curlies[i]){
        printf("Nisu istih dimenzija puzle\n");
        puzzle1.x =0;
        puzzle1.y =0;
        puzzle2.x = 0;
        puzzle2.y = 0;
        flagator = 0;
        break;
    }

    }
    if(flagator && !replaced)replace_pixels(raster);
    flagator=1;

}

void check_puzzle(rafgl_raster_t raster, int posx, int posy){
    int calc;
    puzzle help;

        calc = (posx/86) + (posy/75)*12;
        help = puzzles[calc];
        if(help.x != puzzle2.x && help.y != puzzle2.y)replaced=0;

        if(puzzle1.x == 0 && puzzle1.y == 0)puzzle1 = help;
        else if(!(puzzle1.x == help.x && puzzle1.y == help.y)){
                puzzle2 = help;
                replace_puzzles(raster);
    }
}

void replace_pixels(rafgl_raster_t raster){
    north(raster, puzzle1.curlies[3]);
    south(raster, puzzle1.curlies[1]);
    mid(raster, puzzle1.curlies[2]);
    replace_first_part(raster);
    replace_second_part(raster);
    replaced = 1;
}











