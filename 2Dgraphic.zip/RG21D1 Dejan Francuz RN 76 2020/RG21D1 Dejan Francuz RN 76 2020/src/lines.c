#include <main_state.h>
#include <glad/glad.h>
#include <math.h>

#include <rafgl.h>

#include <main_state.h>

#define MAXLINES  500


typedef struct line
{
    int lenght,x,y,dx,dy;

}line;

line lines[MAXLINES];

static int raster_height;
static int raster_width;

static int colour = 170;

static c = 1;

/** spustamo trenutnu sliku dole, randomujemo x da bi dobili efekat padanja izlomljenog stakla
    istovremeno prikazujemo novu sliku od gore**/

int glass(rafgl_raster_t raster, rafgl_raster_t raster2){
    if(c>675)return 0;
    int x,y;
    for(y = raster_height - 2; y>=0; y--){
        for(x = 0; x < raster_width; x++){
            pixel_at_m(raster, x, y+1).rgba = pixel_at_m(raster, rand()%675, y).rgba;
        }
    }

    for(y = 0; y < c; y++){
        for(x = 0; x < raster_width; x++){
                pixel_at_m(raster, x, y).rgba = pixel_at_m(raster2, x, y).rgba;

        }
    }
    c++;
    return 1;

}

/** positionX + 40, i positionY + 10 treba priblizno da bude pozicija cekica koji udara u 'staklo'
    crtaju se linije, pocetak linije je pozicija cekica, a kraj je randomovana pozicija u krugu od 20 piksela
    lenght je broj koliko cemo puta da iscrtavamo novu liniju iz jedne linije
    colour postaje svetliji kako je staklo blize pucanju
    svaki put kad udari, novih 50 linija se inicijalizuje**/

void lines_main(rafgl_raster_t raster, int positionX, int positionY){

    raster_height = raster.height;
    raster_width = raster.width;


    int x,y,numOfLines=50,i = -1,j=0;

    while(numOfLines && i<MAXLINES){

            i++;

            if(lines[i].lenght>0)continue;
            lines[i].x = positionX+40;
            lines[i].y = positionY + 10;
            lines[i].dx = positionX + rand()%40 - 20;
            lines[i].dy = positionY + rand()%40 - 20;
            lines[i].lenght = 20;

            numOfLines--;

    }

    //sleep(1); // broken glass effect
    update_lines(&raster);
    colour+=10;
    if(colour>255)colour=255;



}

void draw_lines(rafgl_raster_t *raster, line line){
        rafgl_raster_draw_line(raster, line.x, line.y, line.dx, line.dy, rafgl_RGB(colour, colour, colour));
}

void update_lines(rafgl_raster_t *raster){


    for(int i=0; i<MAXLINES ; i++){
        if(lines[i].lenght==0)continue;

        while(1){

        if(lines[i].lenght==1){
            lines[i].lenght += 30;
            break;
        }

        lines[i].x = lines[i].dx;
        lines[i].y = lines[i].dy;

        lines[i].dx = lines[i].x + rand()%40 - 20;
        lines[i].dy = lines[i].y + rand()%40 - 20;

        lines[i].lenght--;

        draw_lines(raster,lines[i]);
        }
    }
}
