#include <main_state.h>
#include <glad/glad.h>
#include <math.h>
#include <windows.h>

#include <time.h>

#include <rafgl.h>

#include <game_constants.h>

#define NUM_SECS 1.0f



static rafgl_raster_t background;
static rafgl_raster_t background2;
static rafgl_raster_t helper;
static rafgl_texture_t texture;
static int colour = 170;


static rafgl_spritesheet_t hero;

static int raster_height=0,raster_width=0;


int pressed;
float location = 0;
float selector = 0;

int animation_running = 0;
int animation_frame = 0;
int direction = 2;

int hero_pos_x = RASTER_WIDTH / 2;
int hero_pos_y = RASTER_HEIGHT / 2;

int hero_speed = 170;

int hover_frames = 0;


void main_state_init(GLFWwindow *window, void *args, int width, int height)
{
        rafgl_raster_load_from_image(&background, "res/images/image-for-project.png");
        rafgl_raster_load_from_image(&background2, "res/images/image-for-project2.png");

        raster_width = width;
        raster_height = height;

        rafgl_raster_init(&helper, width, height);

        for(int x = 0; x < raster_width; x++){
        for(int y = 0; y < raster_height;y++){
            pixel_at_m(helper, x, y).rgba = pixel_at_m(background, x, y).rgba;
        }
    }

        rafgl_spritesheet_init(&hero, "res/images/my_sheet.jpg", 10, 6);

        rafgl_texture_init(&texture);
}

static int counter = 0;
static int broken = 0;

void main_state_update(GLFWwindow *window, float delta_time, rafgl_game_data_t *game_data, void *args)
{

    if(game_data->is_lmb_down){
        game_data->mouse_pos_y = rafgl_clampi(game_data->mouse_pos_y, 0, raster_height - 1);
        game_data->mouse_pos_x = rafgl_clampi(game_data->mouse_pos_x, 0, raster_width - 1);
    check_puzzle(helper, (int)game_data->mouse_pos_x, (int)game_data->mouse_pos_y);
    }

    if(game_data->keys_pressed[RAFGL_KEY_P] && !broken)
     draw_puzzle(helper);

     animation_running = 1;
    if(game_data->keys_down[RAFGL_KEY_W] && !broken)
    {
        hero_pos_y = rafgl_clampi(hero_pos_y - hero_speed * delta_time, 0, raster_height);
        direction = 4;
    }
    else if(game_data->keys_down[RAFGL_KEY_S] && !broken)
    {
        hero_pos_y = rafgl_clampi(hero_pos_y + hero_speed * delta_time, 0, raster_height-65);
        direction = 2;
    }
    else if(game_data->keys_down[RAFGL_KEY_A] && !broken)
    {
        hero_pos_x = rafgl_clampi(hero_pos_x - hero_speed * delta_time, 0, raster_width);
        direction = 5;
    }
    else if(game_data->keys_down[RAFGL_KEY_D] && !broken)
    {
        hero_pos_x = rafgl_clampi(hero_pos_x + hero_speed * delta_time, 0, raster_width-40);
        direction = 3;
    }
    else if(game_data->keys_down[RAFGL_KEY_B]){
    if(counter<8){
    direction = 1;
    lines_main(helper, hero_pos_x, hero_pos_y);
    delay();
    counter++;
    }else if(!broken){
        hero_pos_y = hero_pos_y - 5;
    direction = 0;
    broken = 1;
    }
    }
    else
    {
        animation_running = 0;
    }

    if(animation_running || broken)
    {
        if(hover_frames == 0)
        {
            animation_frame = (animation_frame + 1) % 10;
            hover_frames = 10;
        }
        else
        {
            hover_frames--;
        }

    }

    if(broken){
            hero_pos_y = rafgl_clampi(hero_pos_y + hero_speed * delta_time, 0, raster_height);
            broken = glass(helper, background2);
            if(!broken)counter=0;
    }

    /*if(broken){
            glass(helper);
    broken--;
    }*/




    for(int x = 0; x < raster_width; x++){
        for(int y = 0; y < raster_height;y++){
            pixel_at_m(background, x, y).rgba = pixel_at_m(helper, x, y).rgba;
        }
    }


        rafgl_raster_draw_spritesheet(&background, &hero, animation_frame, direction, hero_pos_x, hero_pos_y);

        rafgl_texture_load_from_raster(&texture, &background);

}

void delay(){
    clock_t delay = NUM_SECS * CLOCKS_PER_SEC; // convert seconds to clock ticks

    clock_t start = clock(); // get starting clock ticks

while((clock() - start) < delay);
}


void main_state_render(GLFWwindow *window, void *args)
{
    /* prikazi teksturu */
    rafgl_texture_show(&texture, 0);
}


void main_state_cleanup(GLFWwindow *window, void *args)
{
    rafgl_raster_cleanup(&background);
    rafgl_texture_cleanup(&texture);

}
